import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
/*
// this must be wrapped inside a Class 
class KYCVerification with VerificationMixin{

  final isVerifyOffline;
  

}


class VoterIDVerification extends KYCVerification{
  final bool isVerifyOffline;
  
  VoterIDVerification({required this.VerifyOffline}) : super(this.thisVerifyOffline);

  @override 
  verify(){
    if(isVerifyOffline == true)
      verifyOffline()
    else 

  }
  
  @overide
  Future<Response> verifyOffline() async{
    // 
  }

  @overide
  Future<Response> verifyOffline() async{
    // 
    OfflineVerificationHandler.loadData('')
  }



}


mixin VerificationMixin{
  void verify();
  Future<Response> verifyOffline();
  Future<Response> verifyOnline();
}


class Apiclient {



    callPost(){
      dio.post(url)
    }

    callGet(){
      dio.get()
    }



}

class OfflineVerificationHandler{

   final String assetPath; 
    OfflineVerificationHandler()


  Future<Response> loadData({required String path}) async {
  final String res = await rootBundle.loadString(path);
  return Response(data: json.decode(res), requestOptions: RequestOptions());
}

}



}
*/
Future<Response> offlineDataProvider({required String path}) async {
  final String res = await rootBundle.loadString(path);
  return Response(data: json.decode(res), requestOptions: RequestOptions());
}
