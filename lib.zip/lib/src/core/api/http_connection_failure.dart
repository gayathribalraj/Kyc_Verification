import 'package:kyc_verification/src/core/api/failure.dart';

class HttpConnectionFailure extends Failure {
  HttpConnectionFailure({required super.message});
}
