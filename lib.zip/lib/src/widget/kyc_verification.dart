/*
  @author   : Gayathri
  @created  : 10/11/2025
  @desc     :VerificationMixin to handle online and offline verification logic using
   Dio for API calls and rootBundle for asset loading.
*/


import 'package:dio/dio.dart';
import 'package:flutter/services.dart';

mixin VerificationMixin {
  Future<Response> verifyOnline(String url);

  Future<Response> verifyOffline(String assetPath);
}


// handle verify offline rootBundle for asset loading.

class OfflineVerificationHandler {
  static Future<Response> loadData(String assetPath) async {
    final String res = await rootBundle.loadString(assetPath);
    return Response(
      data: res,
      requestOptions: RequestOptions(path: assetPath),
    );
  }
}

//handle verify online Dio for API calls

class ApiClient {
  final Dio dio = Dio();

  Future<Response> callPost(String url, {Map<String, dynamic>? data}) async {
    return await dio.post(url, data: data);
  }

  Future<Response> callGet(String url) async {
    return await dio.get(url);
  }
}
