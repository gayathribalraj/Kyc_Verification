/*
  @author   : Gayathri
  @created  : 12/11/2025
  @desc     : Reusable showOtpBottomSheet 
*/

import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';

Future showOtpBottomSheet(BuildContext context) async {
  // Variable to hold the OTP entered by the user
  late String otpPin = '';

  // Show modal bottom sheet
  return await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) {
      return Padding(
        padding: EdgeInsets.only(
          //Adjust for keyboard height
          bottom: MediaQuery.of(context).viewInsets.bottom,
          top: 30,
          left: 20,
          right: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Title text
            const Text(
              'Enter OTP',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // OTP input fields using flutter_otp_text_field package
            OtpTextField(
              numberOfFields: 6,
              showFieldAsBox: true,
              fieldWidth: 45,
              filled: true,
              fillColor: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
              // called when all fields are filled
              onSubmit: (value) {
                // store the enter otp
                otpPin = value;
              },
            ),
            const SizedBox(height: 20),

            // Verify OTP button
            ElevatedButton(
              onPressed: () {
                // close the bottom sheet and return the enterd OTP
                Navigator.pop(context, otpPin);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                backgroundColor: Colors.grey,
              ),
              child: const Text('Verify OTP', style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 20),
          ],
        ),
      );
    },
  );
}

Future showValidateOptions(BuildContext context) async {
  BuildContext ctx = context;
  return await showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (BuildContext context) {
      return Container(
        padding: EdgeInsets.all(16),
        height: 180,
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.qr_code_scanner),
              title: Text('Biometric'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.text_fields),
              title: Text('OTP'),
              onTap: () async {
                Navigator.pop(context);
                showOtpBottomSheet(ctx);
              },
            ),
          ],
        ),
      );
    },
  );
}
