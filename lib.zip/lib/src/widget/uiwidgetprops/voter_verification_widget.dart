/*
  @author   : Gayathri
  @created  : 08/11/2025
  @desc     : A reusable and reactive input field for user verification workflows (Voter/Aadhaar)
  Handles both online and offline verification ,
  Displays dynamic button states for verification results,
  Supports validation, error display, and OTP verification
*/
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:kyc_verification/src/AppData/app_constants.dart';
import 'package:kyc_verification/src/widget/kyc_verification.dart';
import 'package:kyc_verification/src/widget/uiwidgetprops/button_props.dart';
import 'package:kyc_verification/src/widget/uiwidgetprops/otp_validation.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'form_props.dart';
import 'style_props.dart';
import 'package:kyc_verification/src/widget/uiwidgetprops/otp_validation.dart';

// type of verification handle by KYCTextBox

enum VerificationType { voter, aadhaar }

/// code review comments
/// 1. Added null safety to onChange callback.
/// 2. Used widget.styleProps.padding with a default value of EdgeInsets.zero to avoid null issues.
/// 3. Used widget.styleProps.textStyle with a default TextStyle to ensure consistent styling.
/// 4. Improved validationMessages to handle null validator gracefully.
/// 5. Added comments for better code understanding.
/// 6. Ensured proper formatting and indentation for better readability.
/// 7. Used const constructors where applicable for better performance.

// Voter Verification UI A wrapper widget for voter ID verification input using KYCTextBox

class VoterVerification extends StatefulWidget {
  final KYCTextBox kycTextBox;
  VoterVerification({super.key, required this.kycTextBox}) {}

  @override
  State<StatefulWidget> createState() => _VoterVerificationState();
}

class _VoterVerificationState extends State<VoterVerification> {
  @override
  Widget build(BuildContext context) {
    return widget.kycTextBox;
  }
}

// Aadhaar Verification UI A wrapper widget for Aadhaar  verification input using KYCTextBox
class AadhaarVerification extends StatefulWidget {
  final KYCTextBox kycTextBox;
  AadhaarVerification({super.key, required this.kycTextBox}) {}

  @override
  State<StatefulWidget> createState() => _AadhaarVerificationState();
}

class _AadhaarVerificationState extends State<AadhaarVerification> {
  @override
  Widget build(BuildContext context) {
    return widget.kycTextBox;
  }
}

//KYCTextBox Widget uses ReactiveTextField for reactive form integration.

class KYCTextBox extends StatefulWidget {
  final FormProps formProps;
  final StyleProps styleProps;
  final ButtonProps buttonProps;
  final bool isOffline;
  final String? assetPath;
  final String? apiUrl;
  final ValueChanged<Response> onSuccess;
  final ValueChanged<dynamic> onError;
  final Key? fieldKey;
  final String? validationPattern;
  final VerificationType verificationType;

  final ReactiveFormFieldCallback<String>? onChange;
  bool showVerifyButton;
  KYCTextBox({
    this.fieldKey,
    required this.formProps,
    required this.styleProps,
    this.showVerifyButton = false,
    this.onChange,
    required this.buttonProps,
    required this.isOffline,
    this.assetPath,
    required this.onSuccess,
    required this.onError,
    this.validationPattern,
    this.apiUrl,
    required this.verificationType,
  });

  @override
  State<StatefulWidget> createState() => _KYCTextBoxState();
}

// _KYCTextBoxState — Handles UI logic, verification, and state updates
class _KYCTextBoxState extends State<KYCTextBox> with VerificationMixin {
  bool isLoading = false;
  bool isSuccess = false;
  bool isError = false;
  String buttonText = '';
  String id = '';
  bool isValid = true;
  final voterIdPattern = AppConstants.VOTERID_PATTERN;
  final aadhaPattern = AppConstants.AADHAAR_PATTERN;
  bool disabled = false;
  bool isVerified = false;

  @override
  void initState() {
    super.initState();
    buttonText = widget.buttonProps.label;
  }

  // Determines the background color of the Verify button based on the state.
  Color? buttonBackgroundColor() {
    if (isLoading) return Colors.grey;
    if (isSuccess) return Colors.green;
    if (isError) return Colors.red;
    return widget.buttonProps.backgroundColor ?? Color.fromARGB(255, 3, 9, 110);
  }

  //  method to handle input verification (API or offline asset).
  Future<void> verifyInput(String input) async {
    setState(() {
      isLoading = true;
      isSuccess = false;
      isError = false;
    });

    try {
      // Perform verification using either online API or offline asset.

      final response = await verify(
        isOffline: widget.isOffline,
        inputData: input,
        url: widget.apiUrl,
        assetPath: widget.assetPath,
      );

      //  success callback

      widget.onSuccess(response);

      setState(() {
        isSuccess = true;
        buttonText = 'Verified';
        disabled = true;
      });
    } catch (e) {
      //  error callback

      widget.onError(e);
      setState(() {
        isError = true;
        buttonText = 'Failed';
        isValid = true;
        disabled = false;
        isVerified = false;
      });
    } finally {
      await Future.delayed(const Duration(seconds: 1));
      setState(() {
        isLoading = false;
      });
    }
  }

  //Wrapper over VerificationMixin’s verify(), online/offline verification based on user config.
  @override
  Future<Response> verify({
    required bool isOffline,
    String? inputData,
    String? url,
    String? assetPath,
  }) async {
    if (isOffline && assetPath != null) {
      return await verifyOffline(assetPath);
    } else if (!isOffline && url != null) {
      return await verifyOnline(url);
    } else {
      throw Exception('No data source provided');
    }
  }

  @override
  Future<Response> verifyOffline(String assetPath) =>
      OfflineVerificationHandler.loadData(assetPath);

  @override
  Future<Response> verifyOnline(String url) async => ApiClient().callGet(url);

  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsGeometry.all(16),
      child: Row(
        children: [
          Expanded(
            child: Column(
              children: [
                // Textbox section Reactive Form field
                ReactiveTextField<String>(
                  autofocus: false,

                  formControlName: widget.formProps.formControlName,
                  onChanged: (control) {
                    final raw = (control.value ?? '').toString().trim();
                    id = raw;
                    // Validate pattern for either any kyc
                    isValid =
                        (voterIdPattern.hasMatch(raw) ||
                        aadhaPattern.hasMatch(raw));
                    //Reset button state when input changes
                    setState(() {
                      buttonText = widget.buttonProps.label;
                      isSuccess = false;
                      isError = false;
                      isValid = isValid;
                      disabled = false;
                    });
                  },
                  maxLength: widget.formProps.maxLength,
                  style:
                      widget.styleProps.textStyle ??
                      const TextStyle(fontSize: 14),
                  decoration:
                      widget.styleProps.inputDecoration ??
                      InputDecoration(
                        label: RichText(
                          text: TextSpan(
                            text: widget.formProps.label,
                            style:
                                widget.styleProps.textStyle ??
                                const TextStyle(
                                  color: Colors.black,
                                  fontSize: 18,
                                ),
                            children: [
                              TextSpan(
                                text: widget.formProps.mandatory ? ' *' : '',
                                style: const TextStyle(color: Colors.red),
                              ),
                            ],
                          ),
                        ),
                        // Keep error style under the field.
                        errorStyle:
                            widget.styleProps.textStyle ??
                            TextStyle(color: Colors.red, fontSize: 12),
                      ),
                  validationMessages: widget.formProps.validator != null
                      ? {
                          '': (control) {
                            final abstractControl =
                                control as AbstractControl<dynamic>;
                            final errorMessage = widget.formProps.validator!(
                              abstractControl,
                            );
                            return errorMessage;
                          },
                        }
                      : null,
                ),
                // Custom validation error message pattern,
                if (!isValid)
                  Padding(
                    padding: EdgeInsets.only(top: 4, left: 4),
                    child: Text(
                      // 'Please enter a valid Voter ID (e.g. ABC1234567)',
                      '${widget.validationPattern}',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          //Verify Button
          ElevatedButton(
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.resolveWith<Color?>(
                (states) => buttonBackgroundColor(),
              ),
              foregroundColor: MaterialStateProperty.resolveWith<Color?>(
                (states) => widget.buttonProps.foregroundColor,
              ),
              padding: MaterialStateProperty.all(widget.buttonProps.padding),
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    widget.buttonProps.borderRadius,
                  ),
                ),
              ),
            ),
            onPressed: (!isValid || isLoading || disabled)
                ? null
                : () async {
                    // Access the  ReactiveForm in the widget tree
                    final formState = ReactiveForm.of(context);

                    // Ensure the form is a valid FormGroup before proceeding
                    if (formState is! FormGroup) return;
                    final input = formState
                        .control(widget.formProps.formControlName)
                        .value;
                    //Stop if input is empty or null
                    if (input == null || input.toString().isEmpty) return;

                    //Aadhaar flow: open OTP bottom sheet

                    if (widget.verificationType == VerificationType.aadhaar) {
                      final optionBottomSheet = await showValidateOptions(
                        context,
                      );
                      debugPrint("opening aadhaar optionBottomSheet ");
                      final otp = await showOtpBottomSheet(context);
                      debugPrint('opening aadhaar bottomsheet ');
                      if (otp != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("OTP Verified: $otp")),
                        );
                        await Future.delayed(const Duration(milliseconds: 300));
                        await verifyInput(input.toString());
                        setState(() {
                          isLoading = false;
                          isSuccess = true;
                          buttonText = 'Verified';
                          disabled = true;
                        });
                      }
                    } else {
                      //kyc verification directly
                      await verifyInput(input.toString());
                    }
                  },
            child: isLoading
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(buttonText),
          ),
        ],
      ),
    );
  }
}
