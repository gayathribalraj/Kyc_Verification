class ApiRootBundle {
  final voterResponseDataProvider = 'assets/data/voter_validation.json';
  final aadharResponseDataProvider = 'assets/data/aadhaar_validation.json';
  final panResponseDataProvider = 'assets/data/pan_validation.json';
}
