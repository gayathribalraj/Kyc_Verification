/* 
define App's custom types here
 */
typedef RouteProps = Map<String, String>;

// masterchecktype - have prop
