// import 'package:kyc_validation/src/feature/votervalidation/domain/modal/voterid_validate_request.dart';

// abstract class CoappDetailsEvent {}

// class VoterValidateEvent extends CoappDetailsEvent {
//   final VotervalidateRequest request;
//   VoterValidateEvent({required this.request});
// }
