// // ignore_for_file: public_member_api_docs, sort_constructors_first
// import 'package:equatable/equatable.dart';
// import 'package:kyc_validation/src/AppData/app_constants.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/modal/voterid_validate_respose.dart';

// class VotervalidatorState extends Equatable {
//   final SaveStatus? status;
//   final VotervalidateResponse? voterData;

//   VotervalidatorState({this.status, this.voterData});



//     factory VotervalidatorState.init() => VotervalidatorState(
   
//     status: SaveStatus.init,
    
//   );
//   @override
//   List<Object?> get props => [status, voterData];

//   VotervalidatorState copyWith({
//     SaveStatus? status,
//     VotervalidateResponse? voterData
    
//   }) {
//     return VotervalidatorState(
//       status: status ?? this.status,
//       voterData:voterData??this.voterData,
//     );
//   }
// }
