// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:kyc_validation/src/AppData/app_constants.dart';
// import 'package:kyc_validation/src/feature/votervalidation/data/repository/voterid_validate_impl.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/modal/voterid_validate_request.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/repository/voterid_validate_repo.dart';
// import 'package:kyc_validation/src/feature/votervalidation/presentation/votervalidator_event.dart';
// import 'package:kyc_validation/src/feature/votervalidation/presentation/votervalidator_state.dart';

// final class VotervalidatorBloc
//     extends Bloc<VoterValidateEvent, VotervalidatorState> {
//   VotervalidatorBloc():super(VotervalidatorState.init()) {
//     on<VoterValidateEvent>(validateVoter);
//   }

//   Future<void> validateVoter(VoterValidateEvent event, Emitter emit) async {
//     emit(state.copyWith(status: SaveStatus.loading));
//     final VotervalidateRequest votervalidateRequest = event.request;
//     VotervalidateRepo votervalidateRepo = VoterValidateImpl();
//     var responseHandler = await votervalidateRepo.validateVoter(
//       request: votervalidateRequest,
//     );
//     if (responseHandler.isRight()) {
//       emit(
//         state.copyWith(
//           status: SaveStatus.init,
//           voterData: responseHandler.right,
//         ),
//       );
//     } else {
//       emit(state.copyWith(status: SaveStatus.failure));
//       print("SaveStatus.failure  ");
//     }
//   }
// }
