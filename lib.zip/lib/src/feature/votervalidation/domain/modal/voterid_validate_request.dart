// import 'dart:convert';

// class VotervalidateRequest {
//   final String bankName;
//   final String moduleName;
//   final String apiName;
//   final String refNo;
//   final String epicNo;
//   final String caseId;
//   final String consent;
//   final String clientSecret;
//   final String clientId;

//   VotervalidateRequest({
//     required this.bankName,
//     required this.moduleName,
//     required this.apiName,
//     required this.refNo,
//     required this.epicNo,
//     required this.caseId,
//     required this.consent,
//     required this.clientSecret,
//     required this.clientId,
//   });
  
//   VotervalidateRequest copyWith({
//     String? bankName,
//     String? moduleName,
//     String? apiName,
//     String? refNo,
//     String? epicNo,
//     String? caseId,
//     String? consent,
//     String? clientSecret,
//     String? clientId,
//   }) {
//     return VotervalidateRequest(
//       bankName: bankName ?? this.bankName,
//       moduleName: moduleName ?? this.moduleName,
//       apiName: apiName ?? this.apiName,
//       refNo: refNo ?? this.refNo,
//       epicNo: epicNo ?? this.epicNo,
//       caseId: caseId ?? this.caseId,
//       consent: consent ?? this.consent,
//       clientSecret: clientSecret ?? this.clientSecret,
//       clientId: clientId ?? this.clientId,
//     );
//   }

//   Map<String, dynamic> toMap() {
//     return <String, dynamic>{
//       'bankName': bankName,
//       'moduleName': moduleName,
//       'apiName': apiName,
//       'refNo': refNo,
//       'epicNo': epicNo,
//       'caseId': caseId,
//       'consent': consent,
//       'clientSecret': clientSecret,
//       'clientId': clientId,
//     };
//   }

//   factory VotervalidateRequest.fromMap(Map<String, dynamic> map) {
//     return VotervalidateRequest(
//       bankName: map['bankName'] as String,
//       moduleName: map['moduleName'] as String,
//       apiName: map['apiName'] as String,
//       refNo: map['refNo'] as String,
//       epicNo: map['epicNo'] as String,
//       caseId: map['caseId'] as String,
//       consent: map['consent'] as String,
//       clientSecret: map['clientSecret'] as String,
//       clientId: map['clientId'] as String,
//     );
//   }
//   String toJson() => json.encode(toMap());

//   factory VotervalidateRequest.fromJson(String source) => VotervalidateRequest.fromMap(json.decode(source) as Map<String, dynamic>);

//   @override
//   String toString() {
//     return 'VoterIdRequest(bankName: $bankName, moduleName: $moduleName, apiName: $apiName, refNo: $refNo, epicNo: $epicNo, caseId: $caseId, consent: $consent, clientSecret: $clientSecret, clientId: $clientId)';
//   }

//   @override
//   bool operator ==(covariant VotervalidateRequest other) {
//     if (identical(this, other)) return true;
  
//     return 
//       other.bankName == bankName &&
//       other.moduleName == moduleName &&
//       other.apiName == apiName &&
//       other.refNo == refNo &&
//       other.epicNo == epicNo &&
//       other.caseId == caseId &&
//       other.consent == consent &&
//       other.clientSecret == clientSecret &&
//       other.clientId == clientId;
//   }

//   @override
//   int get hashCode {
//     return bankName.hashCode ^
//       moduleName.hashCode ^
//       apiName.hashCode ^
//       refNo.hashCode ^
//       epicNo.hashCode ^
//       caseId.hashCode ^
//       consent.hashCode ^
//       clientSecret.hashCode ^
//       clientId.hashCode;
//   }
// }
