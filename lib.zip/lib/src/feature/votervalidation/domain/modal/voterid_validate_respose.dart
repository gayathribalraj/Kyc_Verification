// // ignore_for_file: public_member_api_docs, sort_constructors_first
// import 'dart:convert';

// import 'package:collection/collection.dart';

// class VotervalidateResponse {
//   final String successMsg;
//   final Map<String, dynamic> voterResponse;
//   final String errorMsg;
//   VotervalidateResponse({
//     required this.successMsg,
//     required this.voterResponse,
//     required this.errorMsg,
//   });

//   VotervalidateResponse copyWith({
//     String? successMsg,
//     Map<String, dynamic>? voterResponse,
//     String? errorMsg,
//   }) {
//     return VotervalidateResponse(
//       successMsg: successMsg ?? this.successMsg,
//       voterResponse: voterResponse ?? this.voterResponse,
//       errorMsg: errorMsg ?? this.errorMsg,
//     );
//   }

//   Map<String, dynamic> toMap() {
//     return <String, dynamic>{
//       'successMsg': successMsg,
//       'voterResponse': voterResponse,
//       'errorMsg': errorMsg,
//     };
//   }

//   factory VotervalidateResponse.fromMap(Map<String, dynamic> map) {
//     return VotervalidateResponse(
//       successMsg: map['successMsg'] as String,
//       voterResponse: Map<String, dynamic>.from(
//         (map['voterResponse'] as Map<String, dynamic>),
//       ),
//       errorMsg: map['errorMsg'] as String,
//     );
//   }

//   String toJson() => json.encode(toMap());

//   factory VotervalidateResponse.fromJson(String source) =>
//       VotervalidateResponse.fromMap(
//         json.decode(source) as Map<String, dynamic>,
//       );

//   @override
//   String toString() =>
//       'VotervalidateResponse(successMsg: $successMsg, voterResponse: $voterResponse, errorMsg: $errorMsg)';

//   @override
//   bool operator ==(covariant VotervalidateResponse other) {
//     if (identical(this, other)) return true;
//     final mapEquals = const DeepCollectionEquality().equals;

//     return other.successMsg == successMsg &&
//         mapEquals(other.voterResponse, voterResponse) &&
//         other.errorMsg == errorMsg;
//   }

//   @override
//   int get hashCode =>
//       successMsg.hashCode ^ voterResponse.hashCode ^ errorMsg.hashCode;
// }
