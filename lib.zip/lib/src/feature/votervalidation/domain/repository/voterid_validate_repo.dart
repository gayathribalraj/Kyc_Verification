
// import 'package:kyc_verification/src/core/api/AsyncResponseHandler.dart';
// import 'package:kyc_verification/src/core/api/failure.dart';
// import 'package:kyc_verification/src/feature/votervalidation/domain/modal/voterid_validate_request.dart';
// import 'package:kyc_verification/src/feature/votervalidation/domain/modal/voterid_validate_respose.dart';

// abstract class VotervalidateRepo {
//   Future<AsyncResponseHandler<Failure, VotervalidateResponse>> validateVoter({
//     required VotervalidateRequest request,
//   });
// }
