// import 'dart:convert';

// import 'package:dio/dio.dart';
// import 'package:flutter/services.dart';
// import 'package:kyc_validation/src/AppData/app_constants.dart';
// import 'package:kyc_validation/src/AppData/globalconfig.dart';
// import 'package:kyc_validation/src/Utils/offline_data_provider.dart';
// import 'package:kyc_validation/src/core/api/AsyncResponseHandler.dart';
// import 'package:kyc_validation/src/core/api/api_client.dart';
// import 'package:kyc_validation/src/core/api/failure.dart';
// import 'package:kyc_validation/src/core/api/http_connection_failure.dart';
// import 'package:kyc_validation/src/core/api/http_exception_parser.dart';
// import 'package:kyc_validation/src/feature/votervalidation/data/datasource/voterid_validate_datasource.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/modal/voterid_validate_request.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/modal/voterid_validate_respose.dart';
// import 'package:kyc_validation/src/feature/votervalidation/domain/repository/voterid_validate_repo.dart';
// import 'package:kyc_validation/src/voter_validation_page.dart';

// class VoterValidateImpl extends VotervalidateRepo {
//   @override
//   Future<AsyncResponseHandler<Failure, VotervalidateResponse>> validateVoter({
//     required VotervalidateRequest request,
//   }) async {
//     HttpConnectionFailure failure = HttpConnectionFailure(message: "");
//     try {
//       final responseData =
//           Globalconfig.isOffline
//               ? await offlineDataProvider(path: AppConstants.voterResponse)
//               : await VoterValidateDatasource(
//                 dio: ApiClient().getDio(),
//               ).validateVoter(request);

//       if (responseData.data['Success']) {
//         final VotervalidateResponse response = VotervalidateResponse.fromMap(
//           responseData.data['responseData']['data'],
//         );
//         return AsyncResponseHandler.right(response);
//       } else {
//         return AsyncResponseHandler.left(failure);
//       }
//     } on DioException catch (e) {
//       HttpConnectionFailure failure =
//           DioHttpExceptionParser(exception: e).parse();
//       return AsyncResponseHandler.left(failure);
//     }
//   }

// }
