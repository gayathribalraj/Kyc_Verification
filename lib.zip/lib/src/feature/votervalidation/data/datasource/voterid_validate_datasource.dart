

import 'package:dio/dio.dart';
import 'package:kyc_verification/src/core/api/api_config.dart';

class VoterValidateDatasource {
  final Dio dio;
  VoterValidateDatasource({required this.dio});

  Future<Response> validateVoter(payload) async {
    return await dio.post(
      ApiConfig.VOTER_API_ENDPOINT,
      
      data: {
        "pancardNumber": payload,
        "token":
            "U2FsdGVkX1/Wa6+JeCIOVLl8LTr8WUocMz8kIGXVbEI9Q32v7zRLrnnvAIeJIVV3",
      },
    );
  }
}
