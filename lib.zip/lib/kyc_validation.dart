library kyc_validation;

export 'src/widget/uiwidgetprops/voter_verification_widget.dart';




// export 'src/widget/otp_screen.dart';
// export 'src/feature/otp/sms_verification.dart';
// export 'src/feature/otp/text_field_pin.dart';
