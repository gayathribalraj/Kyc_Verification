class ApiConfig {
  static const String BASE_URL = "http://192.168.0.19:19084/lendperfect/";
  // static const String BASE_URL = "https://api.restful-api.dev/";
  // static const String BASE_URL = "https://dev.connectperfect.io/cloud_gateway/api/v1.0/karza/";
  static const String VoterId =
      "https://dev.connectperfect.io/cloud_gateway/api/v1.0/karza/voterid/v3";
  static const String Pancard =
      "https://dev.connectperfect.io/cloud_gateway/api/v1.0/karza/Pancard";

}
