library kyc_validation;

export 'src/widget/uiwidgetprops/kyc_verification_widget.dart';
export 'src/widget/uiwidgetprops/consent_form.dart';
export 'src/widget/uiwidgetprops/form_props.dart';
export 'src/widget/uiwidgetprops/otp_validation.dart';
export 'src/widget/uiwidgetprops/button_props.dart';
export 'src/widget/uiwidgetprops/style_props.dart';
export 'src/widget/uiwidgetprops/kyc_wrapper_class.dart';
